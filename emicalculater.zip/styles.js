// Random Number Guessing Game
const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const randomNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

console.log("Guess the number between 1 and 100!");

function askGuess() {
  rl.question("Enter your guess: ", (input) => {
    const guess = parseInt(input, 10);
    attempts++;

    if (isNaN(guess)) {
      console.log("Please enter a valid number.");
    } else if (guess < randomNumber) {
      console.log("Too low! Try again.");
    } else if (guess > randomNumber) {
      console.log("Too high! Try again.");
    } else {
      console.log(`Congratulations! You guessed it in ${attempts} attempts.`);
      rl.close();
      return;
    }

    askGuess();
  });
}

askGuess();
